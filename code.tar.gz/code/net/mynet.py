import requests

def connected_to_internet(url, timeout=5):
    try:
        a = requests.get(url, timeout=timeout)
        return True
    except requests.ConnectionError:
	    return False



import telnetlib
def telnet(cmd):
	hostname="192.168.0.1"
	op=''
	tn = telnetlib.Telnet(hostname)
	tn.read_until("Username: ")
	tn.write('Admin'+'\r')
	tn.read_until("Password: ")
	tn.write('\r')
	tn.read_until("AP#")
	for c in cmd:
		
		tn.write((c)+'\r')
		op = op + tn.read_until("AP#")
	tn.write("exit")
	return op


